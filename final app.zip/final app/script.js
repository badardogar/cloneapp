$(document).ready(function() {
  var map = L.map('map').setView([30.3753, 69.3451], 6); // Set the initial map view

  // Add a basemap
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
  }).addTo(map);

  // Load the WMS layers
  var boundaryLayer = L.tileLayer.wms('http://localhost:8082/geoserver/pk/wms', {
    layers: 'pk:PAK_adm0',
    format: 'image/png',
    transparent: true
  });

  var provinceLayer = L.tileLayer.wms('http://localhost:8082/geoserver/pk/wms', {
    layers: 'pk:PAK_adm1',
    format: 'image/png',
    transparent: true
  });

  var divisionLayer = L.tileLayer.wms('http://localhost:8082/geoserver/pk/wms', {
    layers: 'pk:PAK_adm2',
    format: 'image/png',
    transparent: true
  });

  var districtLayer = L.tileLayer.wms('http://localhost:8082/geoserver/pk/wms', {
    layers: 'pk:PAK_adm3',
    format: 'image/png',
    transparent: true
  });

  // Initialize the map with the boundary layer
  boundaryLayer.addTo(map);

  // Populate the Province dropdown
  $.ajax({
    url: 'http://localhost:8082/geoserver/pk/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=pk%3APAK_adm1&maxFeatures=5000&outputFormat=application%2Fjson',
    dataType: 'json',
    success: function(data) {
      $.each(data.features, function(index, province) {
        $('#provinceSelect').append('<option value="' + province.properties.ID_1 + '">' + province.properties.NAME_1 + '</option>');
      });
    }
  });

  // Handle Province selection change
  $('#provinceSelect').on('change', function() {
    var provinceId = $(this).val();
    $('#divisionSelect').empty().append('<option value="">Select Division</option>');
    $('#districtSelect').empty().append('<option value="">Select District</option>');

    if (provinceId) {
      divisionLayer.setParams({ CQL_FILTER: 'ID_1=' + provinceId });
      divisionLayer.addTo(map);

      // Fit the map bounds to the selected province layer
      $.ajax({
        url: 'http://localhost:8082/geoserver/pk/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=pk%3APAK_adm2&CQL_FILTER=ID_1=' + provinceId + '&maxFeatures=5000&outputFormat=application%2Fjson',
        dataType: 'json',
        success: function(data) {
          var bounds = L.geoJSON(data).getBounds();
          if (bounds.isValid()) {
            map.fitBounds(bounds);
          }
        }
      });

      // Populate the Division dropdown based on the selected province
      $.ajax({
        url: 'http://localhost:8082/geoserver/pk/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=pk%3APAK_adm2&CQL_FILTER=ID_1=' + provinceId + '&maxFeatures=5000&outputFormat=application%2Fjson',
        dataType: 'json',
        success: function(data) {
          $.each(data.features, function(index, division) {
            $('#divisionSelect').append('<option value="' + division.properties.ID_2 + '">' + division.properties.NAME_2 + '</option>');
          });
        }
      });
    } else {
      divisionLayer.removeFrom(map);
    }
  });

  // Handle Division selection change
  $('#divisionSelect').on('change', function() {
    var divisionId = $(this).val();
    $('#districtSelect').empty().append('<option value="">Select District</option>');

    if (divisionId) {
      districtLayer.setParams({ CQL_FILTER: 'ID_2=' + divisionId });
      districtLayer.addTo(map);

      // Fit the map bounds to the selected division layer
      $.ajax({
        url: 'http://localhost:8082/geoserver/pk/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=pk%3APAK_adm3&CQL_FILTER=ID_2=' + divisionId + '&maxFeatures=5000&outputFormat=application%2Fjson',
        dataType: 'json',
        success: function(data) {
          var bounds = L.geoJSON(data).getBounds();
          if (bounds.isValid()) {
            map.fitBounds(bounds);
          }
        }
      });

      // Populate the District dropdown based on the selected division
      $.ajax({
        url: 'http://localhost:8082/geoserver/pk/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=pk%3APAK_adm3&CQL_FILTER=ID_2=' + divisionId + '&maxFeatures=5000&outputFormat=application%2Fjson',
        dataType: 'json',
        success: function(data) {
          $.each(data.features, function(index, district) {
            $('#districtSelect').append('<option value="' + district.properties.ID_3 + '">' + district.properties.NAME_3 + '</option>');
          });
        }
      });

      // Remove the division layer from the map
      divisionLayer.removeFrom(map);
    } else {
      districtLayer.removeFrom(map);
    }
  });

  // Handle District selection change
  $('#districtSelect').on('change', function() {
    var districtId = $(this).val();

    if (districtId) {
      // Remove other districts from the map
      map.eachLayer(function(layer) {
        if (layer !== boundaryLayer && layer !== provinceLayer && layer !== districtLayer) {
          map.removeLayer(layer);
        }
      });

      // Add only the selected district to the map
      districtLayer.setParams({ CQL_FILTER: 'ID_3=' + districtId });
      districtLayer.addTo(map);

      // Fit the map bounds to the selected district layer
      $.ajax({
        url: 'http://localhost:8082/geoserver/pk/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=pk%3APAK_adm3&CQL_FILTER=ID_3=' + districtId + '&maxFeatures=5000&outputFormat=application%2Fjson',
        dataType: 'json',
        success: function(data) {
          var bounds = L.geoJSON(data).getBounds();
          if (bounds.isValid()) {
            map.fitBounds(bounds);
          }
        }
      });
    } else {
      // Remove the district layer from the map
      districtLayer.removeFrom(map);
    }
  });

  // Handle Reset button click
  $('#resetButton').on('click', function() {
    $('#provinceSelect').val('');
    $('#divisionSelect').empty().append('<option value="">Select Division</option>');
    $('#districtSelect').empty().append('<option value="">Select District</option>');
    districtLayer.removeFrom(map);
    boundaryLayer.addTo(map); // Show the boundary layer

    // Fit the map bounds to the initial view
    map.setView([30.3753, 69.3451], 6);
  });
});
